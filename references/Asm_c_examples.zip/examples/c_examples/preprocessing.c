??=include <stdio.h>
#pragma pack(1)
#ifdef DEBUG
#define TWO 0x2
#else
#define TWO 0x1
#endif

int main() ??<
    // haha?????????????????????/
    return 0;
    //line splicing\
    printf("haha");
    int a = TWO;
    int b = 0;
    b = b+++a;
    if(2 == a && 1 != b)
	    printf("hello\n");
    return 0;
??>

