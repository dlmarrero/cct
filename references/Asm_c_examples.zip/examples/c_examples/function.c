#include <stdio.h>

int func1(int a, int b, int c, int d, int e, int f, int g) {
    return a+b+c+d+e+f+g;
}

int main() {
    func1(1,2,3,4,5,6,7);
}

