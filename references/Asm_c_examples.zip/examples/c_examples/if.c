#include <stdio.h>

int main() {
    int a = 2;
    if(2 == a)
        printf("Two equals two!");
    return 0;
}

