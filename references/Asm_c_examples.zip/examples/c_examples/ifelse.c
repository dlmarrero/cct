#include <stdio.h>

int main() {
    int a = 2;
    if(2 == a) {
        printf("Two equals two!");
    } else {
        printf("The world no longer makes sense");
    }
    return 0;
}

